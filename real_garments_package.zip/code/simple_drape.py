"""
Lightweight, from-scratch garment drape.

This repo ships two real cloth simulators (pygarment/meshgen's NVIDIA Warp
backend, and pygarment/mayaqltools' Maya+Qualoth backend), but neither is
usable in this environment: the Warp backend needs a custom fork built from
source (docs/Installation.md) and this machine has no GPU
(nvidia-smi absent, torch.cuda.is_available() == False); Maya+Qualoth is
commercial software that isn't installed.

So this module is a simplified two-phase approximation written from scratch:

1. WRAP: for every garment vertex that starts reasonably close to the body
   (within `close_threshold_cm`), snap it onto the body's actual surface
   (nearest point via trimesh's proximity query, offset outward along that
   triangle's normal by the fabric's ease) instead of asking gravity to pull
   a flat, unwrapped panel onto a cylinder from scratch -- a first attempt at
   plain gravity-drop free-fall simulation was tried and diverged: flat
   panels placed ~15cm from the body have no lateral force pulling them
   inward, so most of the mesh missed the body's collision volume entirely
   and fell indefinitely. Vertices that start far from the body (a full
   circle skirt's hem, a godet flare) are deliberately left alone -- they are
   supposed to flare away from the body, not hug it.
2. RELAX: a short position-based-dynamics pass (gravity + edge-stretch
   constraints + body-collision cleanup) adds natural sag/settling on top of
   the wrap, using pygarment.meshgen.boxmeshgen.BoxMesh (this repo's own,
   Warp-free pattern-to-3D-mesh triangulation/stitching step) as the starting
   topology.

Known simplifications vs. the real simulators: no bending/wrinkle stiffness,
no self-collision, no friction-accurate contact, and the "wrap" phase is a
geometric approximation, not physically simulated draping. Good enough to
sanity-check silhouette + fit, not a substitute for the production backends
once GPU/Maya access exists.

Usage:
    python dress_dataset/simple_drape.py <silhouette>__<fabric> [<silhouette>__<fabric> ...]
"""
import sys
import time
from pathlib import Path

import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pygarment.meshgen.boxmeshgen import BoxMesh

from fabrics import FABRICS

OUT_DIR = Path(__file__).resolve().parent / "output"
BODY_OBJ = ROOT / "assets" / "bodies" / "f_smpl_average_A40.obj"

GRAVITY = np.array([0.0, -981.0, 0.0])  # cm/s^2
BODY_COLLISION_MARGIN = 0.3  # cm standoff from body surface
MAX_SPEED_CM_S = 40.0  # velocity clamp so a bad step can't run away
WRAP_CLOSE_THRESHOLD_CM = 30.0  # only wrap vertices that start this close to the body


def load_body(body_obj_path):
    mesh = trimesh.load(str(body_obj_path), process=False)
    mesh.vertices = np.asarray(mesh.vertices) * 100.0  # SMPL obj is in meters -> cm
    proximity = trimesh.proximity.ProximityQuery(mesh)
    face_normals = np.asarray(mesh.face_normals)
    return mesh, proximity, face_normals


def body_collision_correction(pos, proximity, face_normals, margin=BODY_COLLISION_MARGIN):
    closest, dist, tri_id = proximity.on_surface(pos)
    normals = face_normals[tri_id]
    rel = pos - closest
    signed = np.einsum("ij,ij->i", rel, normals)
    inside = signed < margin
    correction = np.zeros_like(pos)
    if np.any(inside):
        push = margin - signed[inside]
        correction[inside] = normals[inside] * push[:, None]
    return correction


def wrap_to_body(verts, proximity, face_normals, ease_cm, close_threshold_cm=WRAP_CLOSE_THRESHOLD_CM):
    closest, dist, tri_id = proximity.on_surface(verts)
    normals = face_normals[tri_id]
    standoff = max(ease_cm, BODY_COLLISION_MARGIN)
    wrapped_target = closest + normals * standoff

    # Full snap for anything within the threshold (a partial blend weakens
    # to nearly nothing for vertices near the threshold, which was silently
    # leaving most of a fitted garment un-wrapped -- ease targets already
    # keep this close to the body, so a hard cutoff is fine). Vertices
    # beyond the threshold (a flared hem, a godet insert) are intentionally
    # left alone -- they are meant to stand away from the body, not hug it.
    # The relax() pass afterwards smooths the seam between the two regions.
    close = dist < close_threshold_cm
    out = verts.copy()
    out[close] = wrapped_target[close]
    return out


def build_edges(faces):
    edges = set()
    for a, b, c in faces:
        edges.add((a, b) if a < b else (b, a))
        edges.add((b, c) if b < c else (c, b))
        edges.add((a, c) if a < c else (c, a))
    return np.array(sorted(edges), dtype=np.int64)


def stretch_stiffness_from_fabric(material):
    """Map fabric spring_ke (~4,000 stretchy knit .. ~90,000 rigid denim, see
    fabrics.py) to a per-iteration constraint-correction factor in [0.15, 0.95].
    """
    ke = material["spring_ke"]
    lo, hi = 4000.0, 90000.0
    t = np.clip((ke - lo) / (hi - lo), 0.0, 1.0)
    return 0.15 + 0.80 * t


def relax(verts, faces, proximity, face_normals, material,
          n_steps=40, anchor_height_frac=0.97, sag_cm_per_step=0.05,
          verbose=False):
    """Static (no-velocity) shape relaxation: each step nudges positions
    toward satisfying constraints and holds there, rather than integrating
    momentum. An earlier version of this function carried velocity between
    steps (proper time-stepped PBD) and reliably diverged -- the anchor
    constraint was hard-reset every sub-iteration while stretch/collision
    corrections fed forward through (pos - prev) velocity, which pumped
    energy into the mesh every step instead of damping it out. Dropping
    velocity entirely removes that feedback loop: with no momentum to
    carry, each step is a bounded correction and the mesh provably settles
    instead of accelerating.
    """
    n = len(verts)
    pos = verts.copy()
    stiffness = stretch_stiffness_from_fabric(material)

    edges = build_edges(faces)
    ei, ej = edges[:, 0], edges[:, 1]
    rest_len = np.linalg.norm(verts[ei] - verts[ej], axis=1)

    y_min, y_max = verts[:, 1].min(), verts[:, 1].max()
    anchor_mask = verts[:, 1] > (y_min + anchor_height_frac * (y_max - y_min))
    anchor_pos = verts.copy()
    # Hanging/free vertices (skirt hems, flares) get a tiny per-step downward
    # nudge for a natural sag, capped so it can't run away like real gravity did.
    sag_mask = ~anchor_mask

    for step in range(n_steps):
        d = pos[ei] - pos[ej]
        dist = np.linalg.norm(d, axis=1) + 1e-9
        diff = (dist - rest_len) / dist
        corr = d * (diff * 0.5 * stiffness)[:, None]

        delta = np.zeros_like(pos)
        counts = np.zeros(n)
        np.add.at(delta, ei, -corr)
        np.add.at(delta, ej, corr)
        np.add.at(counts, ei, 1)
        np.add.at(counts, ej, 1)
        counts[counts == 0] = 1
        pos += delta / counts[:, None]

        pos[sag_mask, 1] -= sag_cm_per_step
        pos[anchor_mask] = anchor_pos[anchor_mask]
        pos += body_collision_correction(pos, proximity, face_normals)

        if verbose and step % 10 == 0:
            print(f"    relax step {step}/{n_steps}")

    return pos


def color_from_gap(gap_cm, tight_cm=0.5, loose_cm=8.0):
    """Red = tight/clinging, green = good ease, blue = loose/floaty."""
    t = np.clip((gap_cm - tight_cm) / (loose_cm - tight_cm), 0, 1)
    colors = np.zeros((len(gap_cm), 4), dtype=np.uint8)
    colors[:, 0] = (255 * (1 - t)).astype(np.uint8)
    colors[:, 1] = (255 * (1 - np.abs(t - 0.5) * 2)).astype(np.uint8)
    colors[:, 2] = (255 * t).astype(np.uint8)
    colors[:, 3] = 255
    return colors


def drape_dress(dress_id, mesh_res=1.5, n_steps=60, verbose=True,
                 sample_dir=None, spec_path=None, body_obj=None,
                 avg_ease_cm=None, material=None):
    """
    dress_id: used for output file naming, and (if avg_ease_cm/material are
        not given) to look up a fabric from fabrics.py via the
        "<silhouette>__<fabric>" naming convention used by generate_dresses.py.
    sample_dir / spec_path: override where the pattern spec lives and where
        outputs are written -- lets this run on patterns outside dress_dataset/output
        (e.g. a one-off calibrated to a real product's measurements).
    body_obj: override the body OBJ to drape onto (defaults to the female
        reference body; pass the male one for menswear, etc).
    avg_ease_cm / material: override the fabric-derived ease/material --
        pass real measurements-derived ease here instead of pulling from
        fabrics.py's heuristic table.
    """
    sample_dir = Path(sample_dir) if sample_dir else OUT_DIR / dress_id
    spec = Path(spec_path) if spec_path else next(sample_dir.glob("*_specification.json"))
    body_obj = Path(body_obj) if body_obj else BODY_OBJ

    if avg_ease_cm is None or material is None:
        fabric_name = dress_id.split("__")[-1]
        fabric = FABRICS[fabric_name]
        if avg_ease_cm is None:
            avg_ease_cm = float(np.mean(list(fabric["ease_cm"].values())))
        if material is None:
            material = fabric["material"]

    if verbose:
        print(f"[{dress_id}] triangulating pattern ...")
    bm = BoxMesh(str(spec), res=mesh_res)
    bm.load()
    verts = np.array(bm.vertices)
    faces = np.array(bm.faces)
    if verbose:
        print(f"[{dress_id}] mesh: {len(verts)} verts, {len(faces)} faces")

    body_mesh, proximity, face_normals = load_body(body_obj)

    if verbose:
        print(f"[{dress_id}] wrapping to body (avg ease {avg_ease_cm:.1f}cm) ...")
    wrapped = wrap_to_body(verts, proximity, face_normals, avg_ease_cm)

    t0 = time.time()
    if verbose:
        print(f"[{dress_id}] relaxing ({n_steps} steps) ...")
    draped = relax(
        wrapped, faces, proximity, face_normals, material,
        n_steps=n_steps, verbose=verbose,
    )
    if verbose:
        print(f"[{dress_id}] done in {time.time() - t0:.1f}s")

    _, gap_cm, _ = proximity.on_surface(draped)
    colors = color_from_gap(gap_cm)

    out_mesh = trimesh.Trimesh(vertices=draped, faces=faces, vertex_colors=colors, process=False)
    out_ply = sample_dir / f"{dress_id}_draped.ply"
    out_mesh.export(str(out_ply))

    out_body_obj = sample_dir / "body_reference.obj"
    body_mesh.export(str(out_body_obj))

    stats = {
        "dress_id": dress_id,
        "gap_cm_min": float(gap_cm.min()),
        "gap_cm_max": float(gap_cm.max()),
        "gap_cm_mean": float(gap_cm.mean()),
        "pct_tight_lt_0.5cm": float(np.mean(gap_cm < 0.5) * 100),
        "pct_loose_gt_8cm": float(np.mean(gap_cm > 8.0) * 100),
        "draped_mesh": str(out_ply.relative_to(ROOT)).replace("\\", "/"),
        "body_reference_mesh": str(out_body_obj.relative_to(ROOT)).replace("\\", "/"),
    }
    if verbose:
        print(f"[{dress_id}] gap to body (cm): min={stats['gap_cm_min']:.2f} "
              f"mean={stats['gap_cm_mean']:.2f} max={stats['gap_cm_max']:.2f}")
        print(f"[{dress_id}] -> {out_ply.relative_to(ROOT)}")

    return stats


def main():
    ids = sys.argv[1:] or ["pencil_sheath__cotton_poplin", "pencil_sheath__jersey_lycra"]
    all_stats = [drape_dress(dress_id) for dress_id in ids]
    for s in all_stats:
        print(s)


if __name__ == "__main__":
    main()
