"""Quick static preview render (matplotlib) of a draped dress on the body,
colored by the fit heatmap (red=tight, green=good ease, blue=loose)."""
import sys
from pathlib import Path

import numpy as np
import trimesh
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

OUT_DIR = Path(__file__).resolve().parent / "output"


def to_plot_coords(v):
    # Body/garment data is (x, y_height, z_depth). matplotlib's 3D "up" axis
    # is its 3rd column, so reorder to (x, z_depth, y_height) or the figure
    # renders lying on its side (height plotted along a horizontal axis).
    return v[:, [0, 2, 1]]


def render(dress_id):
    sample_dir = OUT_DIR / dress_id
    garment = trimesh.load(str(sample_dir / f"{dress_id}_draped.ply"), process=False)
    body = trimesh.load(str(sample_dir / "body_reference.obj"), process=False)

    body_v = to_plot_coords(np.asarray(body.vertices))
    garment_v = to_plot_coords(np.asarray(garment.vertices))

    # Frame on the garment (+ margin), not the full T-pose body -- the
    # spread arms make the dress look tiny if we frame on everything.
    margin = 25.0
    mins = garment_v.min(axis=0) - margin
    maxs = garment_v.max(axis=0) + margin
    center = (mins + maxs) / 2
    r = max((maxs - mins).max() / 2, 40.0)

    fig = plt.figure(figsize=(9, 11))
    for i, (elev, azim, title) in enumerate([(10, -90, "front"), (10, 90, "back")]):
        ax = fig.add_subplot(1, 2, i + 1, projection="3d")

        body_poly = Poly3DCollection(body_v[body.faces], alpha=0.5)
        body_poly.set_facecolor((0.85, 0.72, 0.62))
        body_poly.set_edgecolor("none")
        ax.add_collection3d(body_poly)

        face_colors = garment.visual.vertex_colors[garment.faces].mean(axis=1) / 255.0
        garment_poly = Poly3DCollection(garment_v[garment.faces], alpha=1.0)
        garment_poly.set_facecolor(face_colors)
        garment_poly.set_edgecolor("none")
        ax.add_collection3d(garment_poly)

        ax.set_xlim(center[0] - r, center[0] + r)
        ax.set_ylim(center[1] - r, center[1] + r)
        ax.set_zlim(center[2] - r, center[2] + r)
        ax.set_box_aspect([1, 1, 1])
        ax.view_init(elev=elev, azim=azim)
        ax.set_axis_off()
        ax.set_title(f"{dress_id} ({title})")

    out_path = sample_dir / f"{dress_id}_preview.png"
    plt.tight_layout()
    plt.savefig(out_path, dpi=110)
    plt.close(fig)
    print(f"-> {out_path}")


if __name__ == "__main__":
    for dress_id in sys.argv[1:]:
        render(dress_id)
