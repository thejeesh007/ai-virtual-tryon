"""
Fabric library for the dress dataset.

Each fabric carries three things:
  - `ease_cm`: the target wearing+design ease (garment measurement minus body
    measurement) at bust/waist/hip, grounded in standard patternmaking ease
    allowances (wovens need positive ease since they don't stretch; knits can
    run zero or negative ease since the fabric itself provides the give).
  - `stretch_give_cm`: how much additional circumference, beyond the flat
    pattern measurement, the fabric itself can stretch to before a garment
    feels restrictive on a body bigger than the reference body. Near-zero for
    rigid wovens (denim), largest for 4-way stretch knits (jersey lycra).
    This is what a fit calculator should treat as the tolerance/slack when
    comparing a specific user's body measurements to this garment.
  - `material`: simulation properties in the schema consumed by
    pygarment/meshgen/sim_config.py (the Warp-based drape simulator already
    vendored in this repo), so these presets are ready to feed straight into
    pattern_data_sim.py once a simulator backend is available.

These are starting presets based on relative fabric behavior (stiffness,
stretch, weight, friction), not lab-measured constants -- treat them as a
reasonable default to simulate with, and replace with measured values if/when
real fabric swatches are characterized.
"""

FABRICS = {
    "cotton_poplin": {
        "label": "Cotton Poplin",
        "kind": "woven",
        "description": "Crisp, lightweight-to-medium woven cotton. Minimal stretch, holds its shape.",
        "ease_cm": {"bust": 6.0, "waist": 3.0, "hip": 4.0},
        "stretch_give_cm": 1.0,
        "material": {
            "garment_tri_ke": 15000.0,
            "garment_tri_ka": 12000.0,
            "garment_tri_kd": 1.5,
            "garment_edge_ke": 1.0,
            "garment_edge_kd": 10.0,
            "spring_ke": 60000.0,
            "spring_kd": 12.0,
            "fabric_density": 1.2,
            "fabric_thickness": 0.15,
            "fabric_friction": 0.4,
        },
    },
    "silk_charmeuse": {
        "label": "Silk Charmeuse",
        "kind": "woven",
        "description": "Very light, fluid, low-bending-stiffness woven silk. Slippery, drapes close to the body.",
        "ease_cm": {"bust": 4.0, "waist": 2.0, "hip": 3.0},
        "stretch_give_cm": 1.5,
        "material": {
            "garment_tri_ke": 8000.0,
            "garment_tri_ka": 9000.0,
            "garment_tri_kd": 1.0,
            "garment_edge_ke": 0.6,
            "garment_edge_kd": 8.0,
            "spring_ke": 70000.0,
            "spring_kd": 10.0,
            "fabric_density": 0.6,
            "fabric_thickness": 0.05,
            "fabric_friction": 0.15,
        },
    },
    "denim": {
        "label": "Denim",
        "kind": "woven",
        "description": "Heavy, stiff, structured woven cotton twill. Barely stretches, resists draping.",
        "ease_cm": {"bust": 9.0, "waist": 5.0, "hip": 6.0},
        "stretch_give_cm": 0.5,
        "material": {
            "garment_tri_ke": 30000.0,
            "garment_tri_ka": 25000.0,
            "garment_tri_kd": 2.0,
            "garment_edge_ke": 2.0,
            "garment_edge_kd": 14.0,
            "spring_ke": 90000.0,
            "spring_kd": 16.0,
            "fabric_density": 2.5,
            "fabric_thickness": 0.4,
            "fabric_friction": 0.6,
        },
    },
    "ponte_knit": {
        "label": "Ponte Knit",
        "kind": "knit",
        "description": "Stable double-knit. Moderate 2-way stretch, holds shape better than jersey.",
        "ease_cm": {"bust": 0.0, "waist": -1.0, "hip": 0.0},
        "stretch_give_cm": 6.0,
        "material": {
            "garment_tri_ke": 5000.0,
            "garment_tri_ka": 4000.0,
            "garment_tri_kd": 1.0,
            "garment_edge_ke": 0.4,
            "garment_edge_kd": 8.0,
            "spring_ke": 15000.0,
            "spring_kd": 8.0,
            "fabric_density": 1.0,
            "fabric_thickness": 0.2,
            "fabric_friction": 0.35,
        },
    },
    "jersey_lycra": {
        "label": "Jersey Lycra",
        "kind": "knit",
        "description": "Soft 4-way stretch jersey. Garment sits smaller than the body; fabric stretch supplies the ease.",
        "ease_cm": {"bust": -4.0, "waist": -3.0, "hip": -3.0},
        "stretch_give_cm": 10.0,
        "material": {
            "garment_tri_ke": 1500.0,
            "garment_tri_ka": 1200.0,
            "garment_tri_kd": 0.5,
            "garment_edge_ke": 0.2,
            "garment_edge_kd": 6.0,
            "spring_ke": 4000.0,
            "spring_kd": 5.0,
            "fabric_density": 0.7,
            "fabric_thickness": 0.1,
            "fabric_friction": 0.3,
        },
    },
}
