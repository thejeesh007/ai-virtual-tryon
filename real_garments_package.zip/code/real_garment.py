"""
Calibrate one of GarmentCode's own garment programs to a REAL product's
published size-guide measurements, instead of our own guessed ease targets,
then drape it with the same wrap+relax pipeline as the dress dataset.

Each entry in PRODUCTS is one real listing's size guide, entered by hand from
a screenshot the user provided (not scraped). Where a size guide publishes
both a garment measurement and its matching body measurement (e.g. "Chest"
and "To Fit Chest"), ease is computed directly from that one table -- no need
to assume our own reference body matches their size chart. Where only the
garment measurement is published, ease falls back to
garment_measurement - reference_body_measurement, using our own bundled body.

Two garment "kind"s are supported, each mapped to the closest GarmentCode
program and its real, code-verified ease knob(s):

  kind="top" (assets/garment_programs/tee.py, the 'Shirt' class -- GarmentCode
  has no polo-collar/ribbed-cuff component, so this approximates any regular/
  oversized-fit knit top as a plain crew neck):
    - design.shirt.width  (multiplies body bust -> chest circumference)
    - design.shirt.length (multiplies body waist_line -> shoulder-to-hem length)
    "Shoulder" has no knob -- Shirt panels derive it from the body's own
    shoulder_w -- reported for comparison only.

  kind="pants" (assets/garment_programs/pants.py, the 'Pants' class):
    - design.waistband.waist (multiplies body waist AND body hips together,
      see assets/garment_programs/bands.py -- Pants' own waist/hip edges are
      tied directly to body measurements with NO ease knob at all; the
      waistband sewn on top is what actually sets the finished circumference.
      Since one multiplier drives both waist and hip, we solve for hip
      -- the named feature of a "straight fit" pant -- and report the
      resulting achieved waist ease alongside the target, same convention
      used for dresses in fabrics.py/generate_dresses.py.)
    - design.pants.length (multiplies body's derived _leg_length -> inseam)
    "Outseam" has no knob (it's a derived waist-to-ankle quantity this
    codebase doesn't expose directly) -- reported for comparison only.

Usage:
    python dress_dataset/real_garment.py <product> [SIZE]
    # SIZE in {S,M,L,XL,XXL,XXXL}, default M
"""
import sys
import copy
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from assets.bodies.body_params import BodyParameters
from assets.garment_programs.meta_garment import MetaGarment

from fabrics import FABRICS
from simple_drape import drape_dress

PRODUCTS = {
    "nobero_polo": {
        "label": "Nobero Classic Polo T-Shirt (Regular Fit)",
        "url": "https://nobero.com/products/classic-polo-t-shirt-10",
        "kind": "top",
        "sleeve_length_frac": 0.3,  # short sleeve
        "fabric_standin": "ponte_knit",
        "size_guide": {
            "S":    {"chest": 99.06,  "shoulder": 43.18, "length": 67.31},
            "M":    {"chest": 104.14, "shoulder": 44.45, "length": 69.85},
            "L":    {"chest": 109.22, "shoulder": 45.72, "length": 72.39},
            "XL":   {"chest": 114.30, "shoulder": 46.99, "length": 74.93},
            "XXL":  {"chest": 119.38, "shoulder": 48.26, "length": 77.47},
            "XXXL": {"chest": 124.46, "shoulder": 49.53, "length": 80.01},
        },
    },
    "nobero_sweatshirt": {
        "label": "Nobero Oversized Sweatshirt (Oversized Fit)",
        "url": "https://nobero.com/products/oversized-sweatshirt-24",
        "kind": "top",
        "sleeve_length_frac": 1.0,  # long sleeve
        "fabric_standin": "ponte_knit",
        "size_guide": {
            "S":    {"chest": 116.84, "to_fit_chest": 96.52,  "shoulder": 60.96, "length": 66.04, "waist": 106.68},
            "M":    {"chest": 121.92, "to_fit_chest": 101.60, "shoulder": 63.50, "length": 68.58, "waist": 111.76},
            "L":    {"chest": 127.00, "to_fit_chest": 106.68, "shoulder": 66.04, "length": 71.12, "waist": 116.84},
            "XL":   {"chest": 132.08, "to_fit_chest": 111.76, "shoulder": 68.58, "length": 72.39, "waist": 121.92},
            "XXL":  {"chest": 137.16, "to_fit_chest": 116.84, "shoulder": 71.12, "length": 73.66, "waist": 127.00},
            "XXXL": {"chest": 142.24, "to_fit_chest": 121.92, "shoulder": 73.66, "length": 74.93, "waist": 132.08},
        },
    },
    "nobero_cargo_pants": {
        "label": "Nobero Travel Cargo Pants (Straight Fit)",
        "url": "https://nobero.com/products/travel-cargo-pants-1",
        "kind": "pants",
        "fabric_standin": "denim",
        "size_guide": {
            "S":    {"waist": 78.74,  "inseam": 73.66, "hip": 99.06,  "outseam": 102.87},
            "M":    {"waist": 83.82,  "inseam": 73.66, "hip": 104.14, "outseam": 104.14},
            "L":    {"waist": 88.90,  "inseam": 73.66, "hip": 109.22, "outseam": 105.41},
            "XL":   {"waist": 93.98,  "inseam": 73.66, "hip": 114.30, "outseam": 106.68},
            "XXL":  {"waist": 99.06,  "inseam": 73.66, "hip": 119.38, "outseam": 107.95},
            "XXXL": {"waist": 104.14, "inseam": 73.66, "hip": 124.46, "outseam": 109.22},
        },
    },
}

BODY_FILE = ROOT / "assets" / "bodies" / "m_smpl_average_A40.yaml"
BODY_OBJ = ROOT / "assets" / "bodies" / "m_smpl_average_A40.obj"
OUT_DIR = Path(__file__).resolve().parent / "output"


def build_top_design(base_design, chest_cm, length_cm, body, sleeve_length_frac):
    design = copy.deepcopy(base_design)
    design["meta"]["upper"]["v"] = "Shirt"
    design["meta"]["wb"]["v"] = None
    design["meta"]["bottom"]["v"] = None

    design["sleeve"]["sleeveless"]["v"] = False
    design["sleeve"]["length"]["v"] = sleeve_length_frac

    chest_mult = chest_cm / body["bust"]
    length_mult = length_cm / body["waist_line"]
    design["shirt"]["width"]["v"] = chest_mult
    design["shirt"]["length"]["v"] = length_mult

    return design, {"shirt.width": chest_mult, "shirt.length": length_mult}


def build_pants_design(base_design, hip_cm, inseam_cm, body):
    design = copy.deepcopy(base_design)
    design["meta"]["upper"]["v"] = None
    design["meta"]["wb"]["v"] = "StraightWB"
    design["meta"]["bottom"]["v"] = "Pants"
    design["waistband"]["width"]["v"] = 0.15

    wb_mult = hip_cm / body["hips"]
    design["waistband"]["waist"]["v"] = wb_mult

    length_mult = inseam_cm / body["_leg_length"]
    design["pants"]["length"]["v"] = length_mult

    return design, {"waistband.waist": wb_mult, "pants.length": length_mult}


def run_top(product, product_key, size, spec, body, base_design, sample_dir):
    design, mults = build_top_design(
        base_design, spec["chest"], spec["length"], body, product["sleeve_length_frac"],
    )

    body_chest_ref = spec.get("to_fit_chest", body["bust"])
    chest_ease_cm = spec["chest"] - body_chest_ref
    ease_source = "size guide's own 'to fit chest' column" if "to_fit_chest" in spec else "our reference body's bust"

    print(f"[{product['label']}] size {size}")
    print(f"  chest: garment={spec['chest']}cm, body ref={body_chest_ref}cm ({ease_source}) "
          f"-> chest ease={chest_ease_cm:.2f}cm (design.shirt.width={mults['shirt.width']:.4f})")
    print(f"  length: garment={spec['length']}cm -> design.shirt.length={mults['shirt.length']:.4f}")
    print(f"  shoulder: garment={spec['shoulder']}cm vs. body shoulder_w={body['shoulder_w']}cm "
          f"(diff {spec['shoulder'] - body['shoulder_w']:.2f}cm) -- not independently calibrated")
    if "waist" in spec:
        print(f"  waist (hem): garment={spec['waist']}cm -- informational only, "
              f"no waist seam on this garment type to calibrate against")

    return design, chest_ease_cm


def run_pants(product, product_key, size, spec, body, base_design, sample_dir):
    design, mults = build_pants_design(base_design, spec["hip"], spec["inseam"], body)

    hip_ease_cm = spec["hip"] - body["hips"]
    achieved_waist_cm = mults["waistband.waist"] * body["waist"]
    waist_ease_achieved = achieved_waist_cm - body["waist"]
    waist_ease_target = spec["waist"] - body["waist"]

    print(f"[{product['label']}] size {size}")
    print(f"  hip: garment={spec['hip']}cm, body={body['hips']}cm -> hip ease={hip_ease_cm:.2f}cm "
          f"(design.waistband.waist={mults['waistband.waist']:.4f}, solved for exactly)")
    print(f"  waist: garment={spec['waist']}cm, body={body['waist']}cm -> target ease={waist_ease_target:.2f}cm, "
          f"achieved ease={waist_ease_achieved:.2f}cm (same multiplier drives both waist and hip -- see module docstring)")
    print(f"  inseam: garment={spec['inseam']}cm -> design.pants.length={mults['pants.length']:.4f}")
    print(f"  outseam: garment={spec['outseam']}cm -- informational only, no direct knob in this codebase")

    avg_ease_cm = (hip_ease_cm + waist_ease_achieved) / 2
    return design, avg_ease_cm


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in PRODUCTS:
        print(f"Usage: python {Path(__file__).name} <product> [SIZE]")
        print(f"Products: {list(PRODUCTS.keys())}")
        return
    product_key = sys.argv[1]
    product = PRODUCTS[product_key]
    size = sys.argv[2].upper() if len(sys.argv) > 2 else "M"
    spec = product["size_guide"][size]

    dress_id = f"real__{product_key}_{size}"
    sample_dir = OUT_DIR / dress_id
    sample_dir.mkdir(parents=True, exist_ok=True)

    with open(ROOT / "assets" / "design_params" / "default.yaml", "r") as f:
        base_design = yaml.safe_load(f)["design"]

    body = BodyParameters(str(BODY_FILE))

    if product["kind"] == "top":
        design, avg_ease_cm = run_top(product, product_key, size, spec, body, base_design, sample_dir)
    elif product["kind"] == "pants":
        design, avg_ease_cm = run_pants(product, product_key, size, spec, body, base_design, sample_dir)
    else:
        raise ValueError(f"Unknown product kind: {product['kind']}")

    piece = MetaGarment(dress_id, body, design)
    piece.assert_total_length()
    piece.assert_non_empty()
    pattern = piece.assembly()
    pattern.serialize(sample_dir, tag="", to_subfolder=False, with_3d=False, with_text=False, view_ids=False)
    body.save(sample_dir)
    with open(sample_dir / "design_params.yaml", "w") as f:
        yaml.dump({"design": design}, f, default_flow_style=False, sort_keys=False)

    material = FABRICS[product["fabric_standin"]]["material"]
    stats = drape_dress(
        dress_id,
        sample_dir=sample_dir,
        body_obj=BODY_OBJ,
        avg_ease_cm=avg_ease_cm,
        material=material,
    )
    print(stats)


if __name__ == "__main__":
    main()
