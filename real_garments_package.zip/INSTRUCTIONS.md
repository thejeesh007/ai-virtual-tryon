# Real-Garment Calibration Package

This is a follow-on to the procedural dress dataset (GarmentCode + a custom
wrap+relax drape). It adds calibrating GarmentCode's own garment programs to
**real products' published size-guide measurements** (screenshots/links the
user provided, entered by hand -- not scraped), instead of made-up ease
targets, then draping the result with the same pipeline.

Paste this whole file as a prompt into a Claude Code session opened at the
root of the GarmentCode project to pick this up where it left off.

## What's in this zip

```
code/
  real_garment.py     # the real-product calibration + drape driver -- START HERE
  simple_drape.py      # the wrap+relax drape solver (gravity-drop physics
                        # was tried first and diverged -- see its docstring)
  fabrics.py            # fabric material presets (stretch/bend/density/friction
                        # + ease_cm) used as physics stand-ins where the
                        # product listing didn't give fabric composition
  render_preview.py    # matplotlib front+back preview PNG renderer
patches/
  pygarment_meshgen/boxmeshgen.py   # PATCHED copy -- see "Required patch" below
outputs/
  real__nobero_polo_M/             # draped Nobero Classic Polo, size M
  real__nobero_sweatshirt_M/       # draped Nobero Oversized Sweatshirt, size M
  real__nobero_cargo_pants_M/      # draped Nobero Travel Cargo Pants, size M
  # each folder has: *_draped.ply (the 3D draped mesh, vertex-colored by fit:
  # red=tight, green=good ease, blue=loose), body_reference.obj (the body it
  # was draped onto), *_preview.png (quick front+back look), *_pattern.*
  # (flat sewing pattern, NOT draped), design_params.yaml, body_measurements.yaml
```

## Setup (once, in the target GarmentCode checkout)

1. Copy `code/*.py` into `dress_dataset/` (create that folder at the repo
   root if it doesn't exist yet).
2. **Required patch**: copy `patches/pygarment_meshgen/boxmeshgen.py` over
   `pygarment/meshgen/boxmeshgen.py` in the checkout. The vendored file has a
   genuine bug (`self.name` referenced on an `Edge` object that doesn't have
   that attribute) that crashes `BoxMesh.load()` at low mesh resolutions.
   The patch just fixes the print statement -- one line, no behavior change.
3. `pip install rtree` -- required for `trimesh.proximity.ProximityQuery`
   (fast nearest-surface-point queries). Without it, `simple_drape.py`'s
   collision correction silently falls back to a much slower/less accurate
   path or fails outright depending on your trimesh version.
4. Copy `outputs/*` into `dress_dataset/output/` if you want the example
   results available without re-running anything.

## How to run

```
# Drape a real product already in the PRODUCTS registry:
python dress_dataset/real_garment.py nobero_polo M
python dress_dataset/real_garment.py nobero_sweatshirt L
python dress_dataset/real_garment.py nobero_cargo_pants XL

# Render a front+back preview PNG of any draped result:
python dress_dataset/render_preview.py real__nobero_polo_M
```

## How to add a new real product

Open `real_garment.py`, add an entry to `PRODUCTS` with:
- `label`, `url`
- `kind`: `"top"` or `"pants"` (the two garment programs currently wired up
  -- see the module docstring for exactly which design params each kind
  calibrates to which real measurement, and which measurements have NO
  matching knob in this codebase and are only reported for comparison)
- `fabric_standin`: closest key from `fabrics.py`'s `FABRICS` dict (used for
  the physics of the relax pass; ease itself comes from the real data, not
  this fabric's own `ease_cm`)
- `sleeve_length_frac` (kind="top" only): ~0.3 short sleeve, ~1.0 long sleeve
- `size_guide`: `{SIZE: {...columns from the screenshot...}}`. If the size
  guide publishes a body measurement column too (e.g. "To Fit Chest"), name
  it `to_fit_chest` -- the code prefers that over our own reference body for
  computing ease, since it's more accurate (same source, no cross-body
  assumption needed).

Then run it the same way: `python dress_dataset/real_garment.py <key> <SIZE>`.

## Known limitations (tell the user these up front, don't let them surface as bugs)

- **This is not the repo's real cloth simulator.** GarmentCode ships two real
  backends (`pygarment/meshgen`'s NVIDIA Warp fork, `pygarment/mayaqltools`'
  Maya+Qualoth) -- neither is usable here: Warp needs a custom fork built
  from source and this environment has no GPU; Maya+Qualoth is commercial
  and not installed. `simple_drape.py` is a from-scratch, simplified
  approximation (documented in its own docstring, including why a first,
  more "physically real" gravity-drop attempt was abandoned after it
  diverged).
- **Sleeves render puffy/balloon-like**, not as a snug tube around the arm --
  the wrap step snaps to the *nearest* body surface point, and a thin
  cylindrical arm gives it nothing to taper against.
- **Shoulder width (tops) and outseam (pants) have no calibration knob** in
  this codebase's garment programs -- they're reported (real vs. body/derived)
  for comparison but the drape can't be made to match them exactly.
- **Waist and hip share one knob** for pants (and skirted dresses) --
  `design.waistband.waist` scales both body waist and body hips by the same
  multiplier (see `assets/garment_programs/bands.py`), so calibrating to a
  real product's hip measurement exactly means the achieved waist ease is
  only approximately correct, not exact. Both target and achieved are
  printed so this is visible, not hidden.
- Polo/ribbed collars and cuffs have no matching GarmentCode component --
  approximated as a plain crew neck.

## Where this fits in the bigger project

Earlier work (not in this zip) built a **procedural** dress dataset:
`generate_dresses.py` + `silhouettes.py` (5 dress silhouettes) +
`fabrics.py` (5 fabric presets with literature-grounded ease targets) +
`build_catalog.py` (assembles `dress_catalog.json`) + `fit.py`
(`classify_fit()` / `best_fitting_dresses()` against that catalog). This
real-garment package is the natural next step: instead of guessing ease
per fabric, calibrate to what a real retailer actually publishes. The
draping mechanics (`simple_drape.py`) are shared between both.

Still open: draping onto the user's actual personalized 3D body (from the
"resize 3D model from user photos" part of the project, which lives
elsewhere and hasn't been connected here yet -- `drape_dress()` in
`simple_drape.py` already accepts a `body_obj` override for exactly this,
it just needs that file and confirmation of its units/orientation).
